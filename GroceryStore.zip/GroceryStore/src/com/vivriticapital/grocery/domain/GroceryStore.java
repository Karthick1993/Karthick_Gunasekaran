package com.vivriticapital.grocery.domain;

import java.util.ArrayList;

public class GroceryStore {
    private ArrayList<Item> groceries = new ArrayList<Item>();
    private String storeName;

    public GroceryStore(String storeName) {
        super();
        this.storeName = storeName;
    }

    
    /**
     * @return the groceries
     */
    public ArrayList<Item> getGroceries() {
        return groceries;
    }

    /**
     * @param groceries
     *            the groceries to set
     */
    public void setGroceries(ArrayList<Item> groceries) {
        this.groceries = groceries;
    }

    /**
     * @return the storeName
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * @param storeName
     *            the storeName to set
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

}
