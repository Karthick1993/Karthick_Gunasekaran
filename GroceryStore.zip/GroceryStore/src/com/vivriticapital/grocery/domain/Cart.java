package com.vivriticapital.grocery.domain;

import java.util.List;

public class Cart {
    private List<Item> cartItems;
    private double totalPrice;
    private double discount;
    private double price;
    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price
     *            the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * @return the cartItems
     */
    public List<Item> getCartItems() {
        return cartItems;
    }

    /**
     * @param cartItems
     *            the cartItems to set
     */
    public void setCartItems(List<Item> cartItems) {
        this.cartItems = cartItems;
    }

    /**
     * @return the totalPrice
     */
    public double getTotalPrice() {
        return totalPrice;
    }

    /**
     * @param totalPrice the totalPrice to set
     */
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    /**
     * @return the discount
     */
    public double getDiscount() {
        return discount;
    }

    /**
     * @param discount the discount to set
     */
    public void setDiscount(double discount) {
        this.discount = discount;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Cart [cartItems=" + cartItems + ", totalPrice=" + totalPrice + ", discount=" + discount + ", price="
                + price + "]";
    }
    
}
