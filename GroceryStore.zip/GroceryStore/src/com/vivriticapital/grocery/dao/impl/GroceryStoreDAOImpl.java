package com.vivriticapital.grocery.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.vivriticapital.grocery.dao.GroceryStoreDAO;
import com.vivriticapital.grocery.domain.Cart;
import com.vivriticapital.grocery.domain.Item;
import com.vivriticapital.grocery.util.GroceryStoreUtil;

public class GroceryStoreDAOImpl implements GroceryStoreDAO {

    private ArrayList<Item> groceries = new ArrayList<Item>();
    private Cart cart = new Cart();
    GroceryStoreUtil<Item> itemUtil = new GroceryStoreUtil<Item>();

    public void newItem(String type, int quantity, double price) {
        Item newItem = new Item(type);
        if (!groceries.contains(newItem)) {
            // Item newItem=new Item(type);
            newItem.setQuantity(quantity);
            newItem.setPrice(price);
            groceries.add(newItem);
        } else {
            System.out.println("Item already available");
        }
    }

    public void update(String type, int quantity, double price) {
        Item newItem = new Item(type);
        if (groceries.contains(newItem)) {
            int index = groceries.indexOf(newItem);
            newItem = groceries.get(index);
            newItem.setQuantity(quantity);
            newItem.setPrice(price);
        } else {

        }
    }

    public int isAvailable(Item item) {
        /*
         * int index=-1; if (groceries.contains(item)) { index= groceries.indexOf(item);
         * }
         */
        return itemUtil.isAvailableInList(groceries, item);
        // return index;

    }

    /**
     * @return the groceries
     */
    public ArrayList<Item> getGroceries() {
        return groceries;
    }

    /**
     * @param groceries
     *            the groceries to set
     */
    public void setGroceries(ArrayList<Item> groceries) {
        this.groceries = groceries;
    }

    @Override
    public void addNewItem(Item item) {
        // TODO Auto-generated method stub
        groceries.add(item);
    }

    @Override
    public void update(Item item) {
        // TODO Auto-generated method stub
        Item newItem = groceries.get(isAvailable(item));
        newItem.setQuantity(item.getQuantity());
        newItem.setPrice(item.getPrice());
    }

    @Override
    public List<Item> listAllItem() {
        // TODO Auto-generated method stub
        return groceries;
    }

    @Override
    public void addToCart(Item item) {
        // TODO Auto-generated method stub
        int index = isAvailable(item);
        if (index > -1 && groceries.get(index).getQuantity() >= item.getQuantity()) {
            item.setPrice(groceries.get(index).getPrice());
            if (cart.getCartItems() != null) {
                cart.getCartItems().add(item);
            } else {
                ArrayList<Item> cartItem = new ArrayList<>();
                cartItem.add(item);
                cart.setCartItems(cartItem);
            }
            cart.setPrice(cart.getPrice() + (item.getQuantity() * groceries.get(index).getPrice()));
            Item newItem = groceries.get(index);
            newItem.setQuantity(newItem.getQuantity() - item.getQuantity());
            System.out.println("Item added to cart");
        } else {
            System.out.println("Item not available in the list/quantity not available");
        }
    }

    @Override
    public void removeFromCart(Item item) {
        // TODO Auto-generated method stub

        if (cart.getCartItems() != null) {
            int index = itemUtil.isAvailableInList(cart.getCartItems(), item);
            int gorceryIndex=itemUtil.isAvailableInList(groceries, item);
            if (index > -1) {
                ArrayList<Item> cartItem = (ArrayList<Item>) cart.getCartItems();
                if (item.getQuantity() == cartItem.get(index).getQuantity()) {
                    cartItem.remove(item);
                } else if (item.getQuantity() < cartItem.get(index).getQuantity()) {
                    Item newItem = cartItem.get(index);
                    newItem.setQuantity(newItem.getQuantity() - item.getQuantity());
                } else {
                    System.out.println("Entered quantity exeeds the available quantity in the cart");
                    item.setQuantity(0);
                }
                Item newItemInList = groceries.get(gorceryIndex);
                newItemInList.setQuantity(newItemInList.getQuantity() + item.getQuantity());
                cart.setPrice(cart.getPrice() - (item.getQuantity() * groceries.get(gorceryIndex).getPrice()));
                System.out.println("Item removed from cart");
            } else {
                System.out.println("Item not available in the list/quantity not available");
            }
        } else {
            System.out.println("Cart is empty");
        }

    }

    @Override
    public Cart listCart() {
        // TODO Auto-generated method stub
        return cart;
    }

    public void initializer() {
        newItem("bread", 15, 9.99);
        newItem("oil", 2, 2.00);
        newItem("eggs", 3, 1.50);
    }

    /**
     * @return the cart
     */
    public Cart getCart() {
        return cart;
    }

    /**
     * @param cart
     *            the cart to set
     */
    public void setCart(Cart cart) {
        this.cart = cart;
    }
}
