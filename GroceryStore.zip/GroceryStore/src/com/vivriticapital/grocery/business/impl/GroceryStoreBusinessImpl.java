package com.vivriticapital.grocery.business.impl;

import java.util.List;

import com.vivriticapital.grocery.business.GroceryStoreBusiness;
import com.vivriticapital.grocery.dao.impl.GroceryStoreDAOImpl;
import com.vivriticapital.grocery.domain.Cart;
import com.vivriticapital.grocery.domain.Item;

public class GroceryStoreBusinessImpl implements GroceryStoreBusiness{
    
    private GroceryStoreDAOImpl groceryStoreDAOImpl=new GroceryStoreDAOImpl();

    @Override
    public void addNewItem(Item item) {
        // TODO Auto-generated method stub
        groceryStoreDAOImpl.addNewItem(item);
    }

    @Override
    public void update(Item item) {
        // TODO Auto-generated method stub
        groceryStoreDAOImpl.update(item);
    }

    @Override
    public List<Item> listAllItem() {
        // TODO Auto-generated method stub
        return groceryStoreDAOImpl.listAllItem();
    }

    @Override
    public void addToCart(Item cart) {
        // TODO Auto-generated method stub
        groceryStoreDAOImpl.addToCart(cart);
    }
    public void initializer() {
        groceryStoreDAOImpl.initializer();
    }
    
    public boolean isAvailable(Item item) {
        return groceryStoreDAOImpl.isAvailable(item)>-1;
    }

    /**
     * @return the groceryStoreDAOImpl
     */
    public GroceryStoreDAOImpl getGroceryStoreDAOImpl() {
        return groceryStoreDAOImpl;
    }

    /**
     * @param groceryStoreDAOImpl the groceryStoreDAOImpl to set
     */
    public void setGroceryStoreDAOImpl(GroceryStoreDAOImpl groceryStoreDAOImpl) {
        this.groceryStoreDAOImpl = groceryStoreDAOImpl;
    }

    @Override
    public void removeFromCart(Item item) {
        // TODO Auto-generated method stub
        groceryStoreDAOImpl.removeFromCart(item);
    }

    @Override
    public Cart listCart() {
        // TODO Auto-generated method stub
        return groceryStoreDAOImpl.listCart();
    }

    
}
