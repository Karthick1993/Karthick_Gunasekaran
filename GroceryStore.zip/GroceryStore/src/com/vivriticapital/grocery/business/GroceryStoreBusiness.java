package com.vivriticapital.grocery.business;

import java.util.List;

import com.vivriticapital.grocery.domain.Cart;
import com.vivriticapital.grocery.domain.Item;

public interface GroceryStoreBusiness {

    void addNewItem(Item item);
    void update(Item item);
    List<Item> listAllItem();
    void addToCart(Item cart);
    void removeFromCart(Item item);
    Cart listCart();
}
