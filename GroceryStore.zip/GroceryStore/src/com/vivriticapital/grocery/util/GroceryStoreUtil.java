package com.vivriticapital.grocery.util;

import java.util.List;

public class GroceryStoreUtil<E> {

    public int isAvailableInList(List<E> list, E object) {
        return list.indexOf(object);
    }
}
