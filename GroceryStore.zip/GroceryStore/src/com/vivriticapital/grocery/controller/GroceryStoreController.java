package com.vivriticapital.grocery.controller;

import java.util.Scanner;

import com.vivriticapital.grocery.business.impl.GroceryStoreBusinessImpl;
import com.vivriticapital.grocery.domain.Item;

public class GroceryStoreController {

    private GroceryStoreBusinessImpl groceryStoreBusinessImpl;

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        {
            GroceryStoreController groceryStoreController = new GroceryStoreController();
            groceryStoreController.setGroceryStoreBusinessImpl(new GroceryStoreBusinessImpl());
            Scanner in = new Scanner(System.in);
            int choice;
            groceryStoreController.groceryStoreBusinessImpl.initializer();
            do {
                System.out.println("MENU: ");
                System.out.println("1. List All Items ");
                System.out.println("2. Add new item");
                System.out.println("3. Update Existing Item ");
                System.out.println("4. Add to cart ");
                System.out.println("5. Remove from cart ");
                System.out.println("6. Show Cart ");
                System.out.println("7. Exit ");
                System.out.println("Enter your choice:");
                choice = in.nextInt();
                switch (choice) {
                case 1:
                    System.out.println(groceryStoreController.groceryStoreBusinessImpl.listAllItem());
                    break;
                case 2:
                    Item item = getInputItem(in);
                    if (!groceryStoreController.groceryStoreBusinessImpl.isAvailable(item)) {
                        groceryStoreController.groceryStoreBusinessImpl.addNewItem(item);
                        System.out.println("Item added successfully");
                    } else {
                        System.out.println("This item already available. Do u want to update y/n");
                        String input = in.next();
                        if ("y".equalsIgnoreCase(input)) {
                            groceryStoreController.groceryStoreBusinessImpl.update(item);
                            System.out.println("Item updated successfully");
                        }
                    }
                    break;
                case 3:
                    item = getInputItem(in);
                    if (groceryStoreController.groceryStoreBusinessImpl.isAvailable(item)) {
                        groceryStoreController.groceryStoreBusinessImpl.update(item);
                        System.out.println("Item updated successfully");
                    } else {
                        System.out.println("This item not available. Do u want to insert y/n");
                        String input = in.next();
                        if ("y".equalsIgnoreCase(input)) {
                            groceryStoreController.groceryStoreBusinessImpl.addNewItem(item);
                            System.out.println("Item added successfully");
                        }
                    }
                    break;
                case 4:
                    System.out.println("Enter Item name:");
                    item = new Item(in.next());
                    System.out.println("Enter quantity:");
                    item.setQuantity(in.nextInt());
                    groceryStoreController.groceryStoreBusinessImpl.addToCart(item);
                    break;
                case 5:
                    System.out.println("Enter Item name:");
                    item = new Item(in.next());
                    System.out.println("Enter quantity:");
                    item.setQuantity(in.nextInt());
                    groceryStoreController.groceryStoreBusinessImpl.removeFromCart(item);
                    break;
                case 6:
                    System.out.println(groceryStoreController.groceryStoreBusinessImpl.listCart());
                    break;
                case 7:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
                }
            } while (choice > 0 && choice < 8);
            in.close();
        }
    }

    private static Item getInputItem(Scanner in) {
        System.out.println("Enter Item name:");
        Item item = new Item(in.next());
        System.out.println("Enter quantity:");
        item.setQuantity(in.nextInt());
        System.out.println("Enter price:");
        item.setPrice(in.nextDouble());
        return item;
    }

    /**
     * @return the groceryStoreBusinessImpl
     */
    public GroceryStoreBusinessImpl getGroceryStoreBusinessImpl() {
        return groceryStoreBusinessImpl;
    }

    /**
     * @param groceryStoreBusinessImpl
     *            the groceryStoreBusinessImpl to set
     */
    public void setGroceryStoreBusinessImpl(GroceryStoreBusinessImpl groceryStoreBusinessImpl) {
        this.groceryStoreBusinessImpl = groceryStoreBusinessImpl;
    }

}
